/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sanmukh.service;

/**
 *
 * @author PyDev
 */
public class ArethmeticService {
    public int getSum(int a,int b)
    {
        return a + b;
    }
}
